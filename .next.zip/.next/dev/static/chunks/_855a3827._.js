(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/services/productService.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "productService",
    ()=>productService
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
const API_URL = `${("TURBOPACK compile-time value", "https://api.alsaifsheesha.online/api")}/public/PublicProducts`;
const productService = {
    async getAll () {
        try {
            const res = await fetch(API_URL, {
                cache: "no-store"
            });
            if (!res.ok) {
                console.error("❌ Failed to fetch products:", res.status, res.statusText);
                return [];
            }
            const text = await res.text(); // Read as text first
            if (!text) {
                console.warn("⚠️ Empty response from API");
                return [];
            }
            const result = JSON.parse(text);
            return result.data || [];
        } catch (err) {
            console.error("🚨 Error fetching products:", err);
            return [];
        }
    },
    async getById (id) {
        try {
            const res = await fetch(`${API_URL}/${id}`, {
                cache: "no-store"
            });
            if (!res.ok) {
                console.error("❌ Failed to fetch product:", res.status, res.statusText);
                return null;
            }
            const text = await res.text();
            if (!text) return null;
            const result = JSON.parse(text);
            return result.data || null;
        } catch (err) {
            console.error("🚨 Error fetching product:", err);
            return null;
        }
    }
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/products/[id]/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// /* eslint-disable @typescript-eslint/no-explicit-any */
// "use client";
// import { useEffect, useState } from "react";
// import { useParams } from "next/navigation";
// import { productService } from "@/services/productService";
// import { useCart } from "@/context/CartContext";
// import Image from "next/image";
// export default function ProductDetails() {
//   const { id } = useParams();
//   const [product, setProduct] = useState<any>(null);
//   const [selectedEdition, setSelectedEdition] = useState("Platinum Edition");
//   const [quantity, setQuantity] = useState(1);
//   const [added, setAdded] = useState(false);
//   const { addToCart } = useCart(); // ✅ from CartContext
//   // ✅ Fetch product by ID
//   useEffect(() => {
//     if (id) {
//       productService.getById(id as string).then(setProduct);
//     }
//   }, [id]);
//   if (!product) {
//     return (
//       <div className="text-center text-gray-400 py-32 text-xl">
//         Loading product details...
//       </div>
//     );
//   }
//   // ✅ Handle quantity update
//   const handleQuantityChange = (change: number) => {
//     setQuantity((prev) => Math.max(1, prev + change));
//   };
//   // ✅ Handle add to cart
//   const handleAddToCart = async () => {
//     await addToCart(product, quantity); // Uses context logic (API/local)
//     setAdded(true);
//     // Hide success message after few seconds
//     setTimeout(() => setAdded(false), 3000);
//   };
//   const total = (product.price * quantity).toFixed(2);
//   return (
//     <section className="py-16 bg-gray-900">
//       <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
//         <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
//           {/* Left - Product Images */}
//           <div className="space-y-4">
//             <div className="aspect-square rounded-2xl overflow-hidden bg-gray-800">
//               <Image
//                 src={product.imageUrl || "/placeholder.png"}
//                 alt={product.name}
//                 width={600}
//                 height={600}
//                 className="w-full h-full object-cover object-top"
//               />
//             </div>
//             <div className="grid grid-cols-4 gap-4">
//               {[1, 2, 3, 4].map((i) => (
//                 <button
//                   key={i}
//                   className={`aspect-square rounded-lg overflow-hidden border-2 transition-colors cursor-pointer ${
//                     i === 1
//                       ? "border-amber-400"
//                       : "border-gray-700 hover:border-gray-600"
//                   }`}
//                 >
//                   <Image
//                     src={product.imageUrl || "/placeholder.png"}
//                     alt={`${product.name} view ${i}`}
//                     width={600}
//                     height={600}
//                     className="w-full h-full object-cover object-top"
//                   />
//                 </button>
//               ))}
//             </div>
//           </div>
//           {/* Right - Product Info */}
//           <div className="space-y-6">
//             <div>
//               <h1 className="text-4xl font-bold text-white mb-4">{product.name}</h1>
//               <div className="flex items-center mb-4">
//                 <div className="flex text-amber-400 mr-3">
//                   <i className="ri-star-fill"></i>
//                   <i className="ri-star-fill"></i>
//                   <i className="ri-star-fill"></i>
//                   <i className="ri-star-fill"></i>
//                   <i className="ri-star-line"></i>
//                 </div>
//                 <span className="text-gray-400">(124 reviews)</span>
//               </div>
//               <div className="flex items-center gap-4 mb-6">
//                 <span className="text-3xl font-bold text-amber-400">
//                   ${product.price.toFixed(2)}
//                 </span>
//                 <span className="text-green-400 text-sm font-medium">
//                   <i className="ri-check-line mr-1"></i>In Stock (15 available)
//                 </span>
//               </div>
//             </div>
//             <p className="text-gray-300 text-lg leading-relaxed">
//               Experience the ultimate in luxury smoking with our Premium Glass Hookah.
//               Crafted from the finest borosilicate glass and featuring an ornate metal
//               stem, this hookah delivers exceptional performance and stunning visual
//               appeal.
//             </p>
//             {/* Edition Selector */}
//             <div>
//               <h3 className="text-lg font-semibold text-white mb-3">Edition</h3>
//               <div className="flex gap-3 flex-wrap">
//                 {[
//                   "Standard - $299.99",
//                   "Gold Edition - $399.99",
//                   "Platinum Edition - $499.99",
//                 ].map((edition) => (
//                   <button
//                     key={edition}
//                     onClick={() => setSelectedEdition(edition)}
//                     className={`px-4 py-2 rounded-lg border transition-colors cursor-pointer whitespace-nowrap ${
//                       selectedEdition === edition
//                         ? "border-amber-400 bg-amber-400/10 text-amber-400"
//                         : "border-gray-600 text-gray-300 hover:border-gray-500"
//                     }`}
//                   >
//                     {edition}
//                   </button>
//                 ))}
//               </div>
//             </div>
//             {/* Quantity Selector */}
//             <div>
//               <h3 className="text-lg font-semibold text-white mb-3">Quantity</h3>
//               <div className="flex items-center gap-4">
//                 <div className="flex items-center border border-gray-600 rounded-lg">
//                   <button
//                     onClick={() => handleQuantityChange(-1)}
//                     className="p-3 text-gray-300 hover:text-amber-400 transition-colors cursor-pointer"
//                   >
//                     <i className="ri-subtract-line"></i>
//                   </button>
//                   <span className="px-4 py-3 text-white font-medium min-w-[60px] text-center">
//                     {quantity}
//                   </span>
//                   <button
//                     onClick={() => handleQuantityChange(1)}
//                     className="p-3 text-gray-300 hover:text-amber-400 transition-colors cursor-pointer"
//                   >
//                     <i className="ri-add-line"></i>
//                   </button>
//                 </div>
//                 <span className="text-gray-400">Total: ${total}</span>
//               </div>
//             </div>
//             {/* Buttons */}
//             <div className="flex gap-4">
//               <button
//                 onClick={handleAddToCart}
//                 className="font-semibold transition-all duration-300 cursor-pointer whitespace-nowrap bg-gradient-to-r from-amber-400 to-yellow-500 text-black hover:from-amber-500 hover:to-yellow-600 shadow-lg hover:shadow-xl px-8 py-4 text-lg rounded-xl flex-1 flex items-center justify-center"
//               >
//                 <i className="ri-shopping-cart-line mr-2"></i>
//                 Add to Cart
//               </button>
//               <button className="w-12 h-12 flex items-center justify-center border border-gray-600 rounded-lg text-gray-300 hover:text-amber-400 hover:border-amber-400 transition-colors cursor-pointer">
//                 <i className="ri-heart-line"></i>
//               </button>
//             </div>
//             {/* Success Message */}
//             {added && (
//               <div className="mt-4 bg-green-800/30 border border-green-600 text-green-300 px-6 py-3 rounded-lg flex items-center justify-between">
//                 <span>
//                   <i className="ri-check-line mr-2"></i>Added to cart successfully!
//                 </span>
//                 <a href="/cart" className="text-green-400 underline hover:text-green-300">
//                   View Cart
//                 </a>
//               </div>
//             )}
//           </div>
//         </div>
//       </div>
//     </section>
//   );
// }
/* eslint-disable @typescript-eslint/no-explicit-any */ __turbopack_context__.s([
    "default",
    ()=>ProductDetails
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$productService$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/services/productService.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$context$2f$CartContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/context/CartContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hot$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-hot-toast/dist/index.mjs [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
function ProductDetails() {
    _s();
    const { id } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParams"])();
    const [product, setProduct] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [quantity, setQuantity] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(1);
    const { addToCart } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$context$2f$CartContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCart"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ProductDetails.useEffect": ()=>{
            if (id) {
                ({
                    "ProductDetails.useEffect": async ()=>{
                        try {
                            const res = await __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$productService$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["productService"].getById(id);
                            setProduct(res.data || res);
                        } catch (error) {
                            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hot$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].error("Failed to load product");
                        }
                    }
                })["ProductDetails.useEffect"]();
            }
        }
    }["ProductDetails.useEffect"], [
        id
    ]);
    if (!product) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "text-center text-gray-400 py-32 text-xl",
            children: "Loading product details..."
        }, void 0, false, {
            fileName: "[project]/app/products/[id]/page.tsx",
            lineNumber: 233,
            columnNumber: 7
        }, this);
    }
    const handleQuantityChange = (change)=>{
        setQuantity((prev)=>Math.max(1, prev + change));
    };
    const handleAddToCart = async ()=>{
        try {
            await addToCart(product.id, quantity);
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hot$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].success("✅ Added to cart!", {
                duration: 2000
            });
        } catch (error) {
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hot$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].error(error.message || "Failed to add to cart");
        }
    };
    const total = (product.price * quantity).toFixed(2);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "py-16 bg-gray-900",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-gray-900 py-4",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                        className: "flex items-center space-x-2 text-sm",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                className: "text-gray-400 hover:text-amber-400 cursor-pointer",
                                children: "Home"
                            }, void 0, false, {
                                fileName: "[project]/app/products/[id]/page.tsx",
                                lineNumber: 265,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                                className: "ri-arrow-right-s-line text-gray-500"
                            }, void 0, false, {
                                fileName: "[project]/app/products/[id]/page.tsx",
                                lineNumber: 266,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                className: "text-gray-400 hover:text-amber-400 cursor-pointer",
                                children: "Shop"
                            }, void 0, false, {
                                fileName: "[project]/app/products/[id]/page.tsx",
                                lineNumber: 268,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                                className: "ri-arrow-right-s-line text-gray-500"
                            }, void 0, false, {
                                fileName: "[project]/app/products/[id]/page.tsx",
                                lineNumber: 269,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-amber-400",
                                children: product.name
                            }, void 0, false, {
                                fileName: "[project]/app/products/[id]/page.tsx",
                                lineNumber: 271,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/products/[id]/page.tsx",
                        lineNumber: 264,
                        columnNumber: 9
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/app/products/[id]/page.tsx",
                    lineNumber: 263,
                    columnNumber: 7
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/products/[id]/page.tsx",
                lineNumber: 262,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-7xl py-16 mx-auto px-4 sm:px-6 lg:px-8",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "grid grid-cols-1 lg:grid-cols-2 gap-12",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "space-y-4",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "aspect-square rounded-2xl overflow-hidden bg-gray-800",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    src: product.imageUrl || "/placeholder.png",
                                    alt: product.name,
                                    width: 600,
                                    height: 600,
                                    className: "w-full h-full object-cover"
                                }, void 0, false, {
                                    fileName: "[project]/app/products/[id]/page.tsx",
                                    lineNumber: 281,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/products/[id]/page.tsx",
                                lineNumber: 280,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/products/[id]/page.tsx",
                            lineNumber: 279,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "space-y-6",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                    className: "text-4xl font-bold text-white",
                                    children: product.name
                                }, void 0, false, {
                                    fileName: "[project]/app/products/[id]/page.tsx",
                                    lineNumber: 293,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-amber-400 text-3xl font-bold",
                                    children: [
                                        "₹",
                                        product.price.toFixed(2)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/products/[id]/page.tsx",
                                    lineNumber: 294,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-gray-300 text-lg leading-relaxed",
                                    children: product.description
                                }, void 0, false, {
                                    fileName: "[project]/app/products/[id]/page.tsx",
                                    lineNumber: 296,
                                    columnNumber: 2
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                            className: "text-lg font-semibold text-white mb-3",
                                            children: "Flavours : "
                                        }, void 0, false, {
                                            fileName: "[project]/app/products/[id]/page.tsx",
                                            lineNumber: 300,
                                            columnNumber: 3
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex gap-3",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    className: "px-4 py-2 rounded-lg border transition-colors cursor-pointer whitespace-nowrap    border-amber-400 bg-amber-400/10 text-amber-400",
                                                    children: "Double Apple"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/products/[id]/page.tsx",
                                                    lineNumber: 304,
                                                    columnNumber: 5
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    className: "px-4 py-2 rounded-lg border transition-colors cursor-pointer whitespace-nowrap    border-gray-600 text-gray-300 hover:border-gray-500",
                                                    children: "Mint"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/products/[id]/page.tsx",
                                                    lineNumber: 310,
                                                    columnNumber: 5
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    className: "px-4 py-2 rounded-lg border transition-colors cursor-pointer whitespace-nowrap    border-gray-600 text-gray-300 hover:border-gray-500",
                                                    children: "Grape"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/products/[id]/page.tsx",
                                                    lineNumber: 317,
                                                    columnNumber: 5
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    className: "px-4 py-2 rounded-lg border transition-colors cursor-pointer whitespace-nowrap    border-gray-600 text-gray-300 hover:border-gray-500",
                                                    children: "Vanilla"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/products/[id]/page.tsx",
                                                    lineNumber: 322,
                                                    columnNumber: 6
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    className: "px-4 py-2 rounded-lg border transition-colors cursor-pointer whitespace-nowrap    border-gray-600 text-gray-300 hover:border-gray-500",
                                                    children: "Peach"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/products/[id]/page.tsx",
                                                    lineNumber: 327,
                                                    columnNumber: 5
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/products/[id]/page.tsx",
                                            lineNumber: 302,
                                            columnNumber: 3
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/products/[id]/page.tsx",
                                    lineNumber: 299,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                            className: "text-lg font-semibold text-white mb-2",
                                            children: "Quantity"
                                        }, void 0, false, {
                                            fileName: "[project]/app/products/[id]/page.tsx",
                                            lineNumber: 337,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-center gap-4",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex items-center border border-gray-600 rounded-lg",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                            onClick: ()=>handleQuantityChange(-1),
                                                            className: "p-3 text-gray-300 hover:text-amber-400",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                                                                className: "ri-subtract-line"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/products/[id]/page.tsx",
                                                                lineNumber: 344,
                                                                columnNumber: 21
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/products/[id]/page.tsx",
                                                            lineNumber: 340,
                                                            columnNumber: 19
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "px-4 py-3 text-white font-medium",
                                                            children: quantity
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/products/[id]/page.tsx",
                                                            lineNumber: 346,
                                                            columnNumber: 19
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                            onClick: ()=>handleQuantityChange(1),
                                                            className: "p-3 text-gray-300 hover:text-amber-400",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                                                                className: "ri-add-line"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/products/[id]/page.tsx",
                                                                lineNumber: 353,
                                                                columnNumber: 21
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/products/[id]/page.tsx",
                                                            lineNumber: 349,
                                                            columnNumber: 19
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/products/[id]/page.tsx",
                                                    lineNumber: 339,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-gray-400",
                                                    children: [
                                                        "Total: ₹",
                                                        total
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/products/[id]/page.tsx",
                                                    lineNumber: 356,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/products/[id]/page.tsx",
                                            lineNumber: 338,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/products/[id]/page.tsx",
                                    lineNumber: 336,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex gap-4",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: handleAddToCart,
                                        className: "flex-1 bg-gradient-to-r from-amber-400 to-yellow-500 text-black font-semibold px-8 py-4 rounded-xl hover:from-amber-500 hover:to-yellow-600 transition-all",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                                                className: "ri-shopping-cart-line mr-2"
                                            }, void 0, false, {
                                                fileName: "[project]/app/products/[id]/page.tsx",
                                                lineNumber: 366,
                                                columnNumber: 17
                                            }, this),
                                            "Add to Cart"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/products/[id]/page.tsx",
                                        lineNumber: 362,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/products/[id]/page.tsx",
                                    lineNumber: 361,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/products/[id]/page.tsx",
                            lineNumber: 292,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/products/[id]/page.tsx",
                    lineNumber: 276,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/products/[id]/page.tsx",
                lineNumber: 275,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/products/[id]/page.tsx",
        lineNumber: 261,
        columnNumber: 5
    }, this);
}
_s(ProductDetails, "JrTpLUvZBjYFXWoGNBPl+1KpCX4=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParams"],
        __TURBOPACK__imported__module__$5b$project$5d2f$context$2f$CartContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCart"]
    ];
});
_c = ProductDetails;
var _c;
__turbopack_context__.k.register(_c, "ProductDetails");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=_855a3827._.js.map