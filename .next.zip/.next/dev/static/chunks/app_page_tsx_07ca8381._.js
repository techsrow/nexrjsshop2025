(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_remixicon_fonts_remixicon_1f416884.css",
  "static/chunks/node_modules_next_dist_60d9f176._.js",
  "static/chunks/_d842a367._.js"
],
    source: "dynamic"
});
