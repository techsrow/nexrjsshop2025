module.exports=[98711,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_products_%5Bid%5D_page_actions_b4387cde.js.map