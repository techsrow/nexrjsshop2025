module.exports=[58370,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_signup_page_actions_0a2f511f.js.map