globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/ec06067cc9bc06ac.js",
    "static/chunks/248cba0fcb3874ed.js",
    "static/chunks/4d8157714a724382.js",
    "static/chunks/73a330e38f4c895c.js",
    "static/chunks/96dbdc0078c3e232.js",
    "static/chunks/turbopack-08da013a503966be.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];